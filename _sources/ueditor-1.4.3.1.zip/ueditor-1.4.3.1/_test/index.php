<?php 
Header('Location:../_test/tools/br/list.php');
?>